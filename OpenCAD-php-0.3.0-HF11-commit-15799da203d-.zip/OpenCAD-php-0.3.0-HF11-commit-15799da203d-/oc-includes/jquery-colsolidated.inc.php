    <!-- jQuery -->
    <script src="<?php echo BASE_URL; ?>/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo BASE_URL; ?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo BASE_URL; ?>/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo BASE_URL; ?>/vendors/nprogress/nprogress.js"></script>
    <!-- Datatables -->
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>

    <!-- Bootstrap Select -->
    <!-- Latest compiled and minified JavaScript -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.1/js/bootstrap-select.min.js"></script>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.1/css/bootstrap-select.min.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

    <!-- PNotify -->
    <script src="<?php echo BASE_URL; ?>/vendors/pnotify/dist/pnotify.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/pnotify/dist/pnotify.buttons.js"></script>
    <script src="<?php echo BASE_URL; ?>/vendors/pnotify/dist/pnotify.nonblock.js"></script>


    <!-- Custom Theme Scripts -->
    <script src="<?php echo BASE_URL; ?>/js/custom.js"></script>
    <script src="<?php echo BASE_URL; ?>/js/OpenCAD.js"></script>
